SELECT 
    COUNT(t.id) AS ticketCount
FROM glpi_tickets t
WHERE 
    t.status IN (3)
    AND t.is_deleted = 0
    [[AND t.date >= {{start_date}}
      AND t.date < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]];