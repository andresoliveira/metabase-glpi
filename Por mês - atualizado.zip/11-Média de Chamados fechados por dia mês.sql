SELECT 
    DATE_FORMAT(t.closedate, '%Y-%m') AS Mes,
    ROUND(
        COUNT(t.id) / NULLIF(COUNT(DISTINCT DATE(t.closedate)), 0),
        2
    ) AS media_por_dia
FROM 
    glpi_tickets t
WHERE 
    t.status IN (5,6)
    AND t.is_deleted = 0
    AND t.closedate IS NOT NULL
    [[AND t.closedate >= {{start_date}}
      AND t.closedate < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]
GROUP BY 
    Mes
ORDER BY 
    Mes DESC;