SELECT 
    COUNT(t.id) AS total_chamados
FROM
    glpi_tickets t
WHERE
    t.status IN (1, 2, 3, 4, 5, 6)
    AND t.is_deleted = 0
    [[AND t.date_creation >= {{data_inicial}} 
      AND t.date_creation < DATE_ADD({{data_final}}, INTERVAL 1 DAY)]]


