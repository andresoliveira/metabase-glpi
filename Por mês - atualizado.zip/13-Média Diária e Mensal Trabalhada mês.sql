SELECT 
    DATE_FORMAT(task.date, '%Y-%m') AS Mes,

    -- Média diária (tempo médio por tarefa)
    CONCAT(
        TIME_FORMAT(
            SEC_TO_TIME(AVG(task.actiontime)), 
            '%H:%i'
        ), 
        'h'
    ) AS Media_Diaria,

    -- Média mensal (tempo total dividido pelos dias com atividade)
    CONCAT(
        TIME_FORMAT(
            SEC_TO_TIME(
                SUM(task.actiontime) / NULLIF(COUNT(DISTINCT DATE(task.date)), 0)
            ),
            '%H:%i'
        ),
        'h'
    ) AS Media_Mensal

FROM glpi_tickettasks task

INNER JOIN glpi_tickets t
    ON t.id = task.tickets_id

INNER JOIN glpi_tickets_users tu
    ON tu.tickets_id = t.id 
    AND tu.type = 2

WHERE 
    tu.users_id IN (852, 352, 705, 166, 344, 816, 955)
    AND t.status IN (2,3,4,5,6)
    AND task.actiontime IS NOT NULL

    [[AND task.date >= {{start_date}}
      AND task.date < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]

GROUP BY Mes
ORDER BY Mes DESC;