SELECT 
    m.Mes,
    m.Abertos,
    m.Fechados,

    -- Backlog acumulado mês a mês
    SUM(m.Abertos - m.Fechados) 
        OVER (ORDER BY m.Mes ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
        AS Backlog

FROM (

    SELECT 
        DATE_FORMAT(dia, '%Y-%m') AS Mes,
        SUM(abertos) AS Abertos,
        SUM(fechados) AS Fechados
    FROM (

        -- Chamados Abertos por mês
        SELECT 
            DATE(t.date_creation) AS dia,
            COUNT(t.id) AS abertos,
            0 AS fechados
        FROM glpi_tickets t
        WHERE 
            t.is_deleted = 0
            [[AND t.date_creation >= {{start_date}}
              AND t.date_creation < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]
        GROUP BY DATE(t.date_creation)

        UNION ALL

        -- Chamados Fechados por mês
        SELECT 
            DATE(t.closedate) AS dia,
            0 AS abertos,
            COUNT(t.id) AS fechados
        FROM glpi_tickets t
        WHERE 
            t.status IN (5,6)
            AND t.is_deleted = 0
            AND t.closedate IS NOT NULL
            [[AND t.closedate >= {{start_date}}
              AND t.closedate < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]
        GROUP BY DATE(t.closedate)

    ) base

    GROUP BY Mes

) m

ORDER BY m.Mes ASC;