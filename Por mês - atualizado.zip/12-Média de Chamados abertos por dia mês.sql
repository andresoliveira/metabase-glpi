SELECT 
    ROUND(
        COUNT(t.id) / NULLIF(COUNT(DISTINCT DATE(t.date)), 0),
        2
    ) AS Media_Chamados_Por_Dia
FROM 
    glpi_tickets t
WHERE 
    t.date IS NOT NULL
    AND t.is_deleted = 0
    [[AND t.date >= {{start_date}}
      AND t.date < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]];