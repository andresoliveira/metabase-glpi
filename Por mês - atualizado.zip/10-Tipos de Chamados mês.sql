SELECT 
    COUNT(t.id) AS total,
    CASE
        WHEN t.type = 1 THEN 'Incidente'
        WHEN t.type = 2 THEN 'Requisição'
    END AS `TIPOS DE CHAMADOS`
FROM
    glpi_tickets t
WHERE
    t.status IN (1,2,3,4,5,6)
    AND t.is_deleted = 0
    [[AND t.date >= {{start_date}}
      AND t.date < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]
GROUP BY
    t.type
ORDER BY
    t.type;