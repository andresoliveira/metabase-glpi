SELECT 
    COUNT(t.id) AS total,
    CASE
        WHEN t.priority = 1 THEN 'Muito Baixa'
        WHEN t.priority = 2 THEN 'Baixa'
        WHEN t.priority = 3 THEN 'Média'
        WHEN t.priority = 4 THEN 'Alta'
        WHEN t.priority = 5 THEN 'Muito Alta'
    END AS PRIORIDADE
FROM
    glpi_tickets t
WHERE
    t.status IN (1,2,3,4,5,6)
    AND t.is_deleted = 0
    [[AND t.date >= {{start_date}} 
      AND t.date < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]
GROUP BY
    t.priority
ORDER BY
    t.priority;