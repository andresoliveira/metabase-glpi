SELECT 
    COUNT(DISTINCT t.id) AS ticketCount
FROM glpi_tickets t
INNER JOIN glpi_tickets_users tu
    ON tu.tickets_id = t.id 
    AND tu.type = 2

WHERE t.status = 2
  AND t.is_deleted = 0
  AND tu.users_id = 852
  [[AND t.date >= {{start_date}}
    AND t.date < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]];