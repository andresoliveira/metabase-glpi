WITH estoque_inicial AS (

    -- Chamados ainda abertos antes do período
    SELECT 
        COUNT(DISTINCT t.id) AS saldo_inicial
    FROM glpi_tickets t
    INNER JOIN glpi_tickets_users tu
        ON tu.tickets_id = t.id AND tu.type = 2
    WHERE 
        t.is_deleted = 0
        AND tu.users_id = 852
        AND t.date_creation < {{start_date}}
        AND (t.closedate IS NULL OR t.closedate >= {{start_date}})

),

movimentacao AS (

    SELECT 
        DATE_FORMAT(dia, '%Y-%m') AS Mes,
        SUM(abertos) AS Abertos,
        SUM(fechados) AS Fechados
    FROM (

        -- Abertos no período
        SELECT 
            DATE(t.date_creation) AS dia,
            COUNT(DISTINCT t.id) AS abertos,
            0 AS fechados
        FROM glpi_tickets t
        INNER JOIN glpi_tickets_users tu
            ON tu.tickets_id = t.id AND tu.type = 2
        WHERE 
            t.is_deleted = 0
            AND tu.users_id = 852
            [[AND t.date_creation >= {{start_date}}
              AND t.date_creation < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]
        GROUP BY DATE(t.date_creation)

        UNION ALL

        -- Fechados no período
        SELECT 
            DATE(t.closedate) AS dia,
            0 AS abertos,
            COUNT(DISTINCT t.id) AS fechados
        FROM glpi_tickets t
        INNER JOIN glpi_tickets_users tu
            ON tu.tickets_id = t.id AND tu.type = 2
        WHERE 
            t.status IN (5,6)
            AND t.is_deleted = 0
            AND t.closedate IS NOT NULL
            AND tu.users_id = 852
            [[AND t.closedate >= {{start_date}}
              AND t.closedate < DATE_ADD({{end_date}}, INTERVAL 1 DAY)]]
        GROUP BY DATE(t.closedate)

    ) base
    GROUP BY Mes
)

SELECT 
    m.Mes,
    m.Abertos,
    m.Fechados,

    -- Backlog real acumulado
    (
        (SELECT saldo_inicial FROM estoque_inicial)
        +
        SUM(m.Abertos - m.Fechados)
            OVER (ORDER BY m.Mes ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
    ) AS Backlog_Real

FROM movimentacao m
ORDER BY m.Mes ASC;